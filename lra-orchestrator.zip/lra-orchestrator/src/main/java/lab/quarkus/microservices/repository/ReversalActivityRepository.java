package lab.quarkus.microservices.repository;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import lab.quarkus.microservices.entity.ForwardActivity;
import lab.quarkus.microservices.entity.ReversalActivity;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class ReversalActivityRepository implements PanacheRepository<ReversalActivity> {

    public void saveActivity(ReversalActivity reversalActivity){
        persist(reversalActivity);
    }

    public List<ReversalActivity> findByName(String name){
        return find("sagaName", name).list();
    }
}